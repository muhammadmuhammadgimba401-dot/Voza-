# VOZZA GitHub Starter (Front-end only)

## Included
- `index.html`: responsive interactive prototype
- Social feed demo with temporary posts and likes
- Product listings and temporary product creation
- True Price Checker (product price + delivery)
- Sample Seller Trust section
- Sample Local Shop Finder
- Buyer Protection complaint form demo
- Seller dashboard and creator tools mockups
- Profile demo

## Put it on GitHub
1. Create a repository on GitHub.
2. Upload `index.html` and `README.md`.
3. To publish it, open repository Settings → Pages and select the branch containing `index.html`.
4. Open the Pages URL when GitHub provides it.

## Important
This is a prototype, not a complete production app. It has no backend or database. It uses no LocalStorage and does not include Cloudflare D1, R2, Paystack, or any payment integration. All data is sample data. Actions disappear when the page refreshes. Accounts, real uploads, live prices, real orders, seller verification, refunds, payment holding, creator payouts, and real notifications are not connected. Do not present sample seller statistics as real data. A secure backend and real operational workflows are required before public launch.
